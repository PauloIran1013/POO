import { Usuario } from "./interface";

export class Cliente implements Usuario {
    id: number;
    nome: string;
    email: string;
    senha: string;
    cpf: string;
    endereco: string;
    constructor(id:number,nome: string,email: string,senha: string,cpf: string,endereco: string){
            this.id = id;
            this.nome = nome;
            this.email = email;
            this.senha = senha;
            this.cpf = cpf;
            this.endereco = endereco;

        }

        exibirInfo(): void {
            console.log(`Nome: ${this.nome}, Email:${this.email}, CPF: ${this.cpf}, Endereço: ${this.endereco}`)
        }

        visualizarJogos(): void {
            // Jogo.listarjogos()
        }

}