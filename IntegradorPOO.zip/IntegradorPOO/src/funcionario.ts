import { Usuario } from "./interface";
import { Jogo } from "./Jogos";

export class Funcionario implements Usuario {
    id: number;
    nome: string;
    email: string;
    cpf: string;
    endereco: string;
    private salario: number;
    private cargo:string;

    constructor(id:number,nome: string,email: string,senha: string,cpf: string,endereco: string, salario:number, cargo:string){
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.cpf = cpf;
        this.endereco = endereco;
        this.salario = salario;
        this.cargo = cargo;
    }

    
    public getCargo() : string {
        return this.cargo
    }

    
    public getSalario() : number {
        return this.salario
    }

    
    public setSalario(novoSalario:number) {
        if (novoSalario<=0) {
            console.log("Por favor adicione um salario valído! Não transforme seu funcionário em um escravo!");
            
        }else{
            this.salario = novoSalario;
        }
    }
    
    public exibirInfo(): void {
    console.log("Informações do funcionário:");
    console.log(`ID: ${this.id}`);
    console.log(`Nome: ${this.nome}`);
    console.log(`Email: ${this.email}`);
    console.log(`CPF: ${this.cpf}`);
    console.log(`Endereço: ${this.endereco}`);
    console.log(`Cargo: ${this.cargo}`);
    console.log(`Salário: R$ ${this.salario.toFixed(2)}`);
    }

    public visualizarJogos(jogo:Jogo){
        Jogo.listarJogos(jogo)
    }

    public addJogo(jogo:Jogo):void{
    Jogo.addJogo(jogo)
    }

    public removerJogo(jogo:Jogo):void{
        Jogo.jogosDisponiveis = Jogo.jogosDisponiveis.filter((j) => j.getId() !== jogo.getId());
        console.log(`Jogo "${jogo.getNome()}" removido da lista de jogos disponíveis.`);
    
}
}

const repositorioDeJogos = new Jogo(0, "", "", "", "", 0); // Um jogo vazio só para gerenciar a lista

// Criando jogos
const jogo1 = new Jogo(1, "FIFA 23", "Esporte", "Jogo de futebol", "PC", 199.99);
const jogo2 = new Jogo(2, "The Witcher 3", "RPG", "Aventura épica", "PC", 149.99);

// Adicionando os jogos ao repositório
repositorioDeJogos.jogo.adicionarJogo(jogo1);
repositorioDeJogos.jogo.adicionarJogo(jogo2);

// Listando os jogos disponíveis
repositorioDeJogos.jogo.listarJogos();



// import { Usuario } from "./interface";
// import { Jogo } from "./Jogos";

// export class Funcionario implements Usuario {
//   id: number;
//   nome: string;
//   email: string;
//   cpf: string;
//   endereco: string;
//   private salario: number;
//   private cargo: string;

//   constructor(id: number, nome: string, email: string, senha: string, cpf: string, endereco: string, salario: number, cargo: string) {
//     this.id = id;
//     this.nome = nome;
//     this.email = email;
//     this.cpf = cpf;
//     this.endereco = endereco;
//     this.salario = salario;
//     this.cargo = cargo;
//   }

//   public getCargo(): string {
//     return this.cargo;
//   }

//   public getSalario(): number {
//     return this.salario;
//   }

//   public setSalario(novoSalario: number): void {
//     if (novoSalario <= 0) {
//       console.log("Por favor adicione um salário válido! Não transforme seu funcionário em um escravo!");
//     } else {
//       this.salario = novoSalario;
//     }
//   }

//   public exibirInfo(): void {
//     console.log("Informações do funcionário:");
//     console.log(`ID: ${this.id}`);
//     console.log(`Nome: ${this.nome}`);
//     console.log(`Email: ${this.email}`);
//     console.log(`CPF: ${this.cpf}`);
//     console.log(`Endereço: ${this.endereco}`);
//     console.log(`Cargo: ${this.cargo}`);
//     console.log(`Salário: R$ ${this.salario.toFixed(2)}`);
//   }

//   public visualizarJogos(): void {
//     Jogo.listarJogos(); // Listar jogos disponíveis
//   }

//   public addJogo(jogo: Jogo): void {
//     Jogo.adicionarJogo(jogo); // Adicionar jogo à lista
//   }

//   public removerJogo(jogo: Jogo): void {
//     Jogo.jogosDisponiveis = Jogo.jogosDisponiveis.filter((j) => j.getId() !== jogo.getId());
//     console.log(`Jogo "${jogo.getNome()}" removido da lista de jogos disponíveis.`);
//   }
// }
