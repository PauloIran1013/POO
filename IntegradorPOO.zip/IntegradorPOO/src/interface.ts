import { Jogo } from "./Jogos"

export interface Usuario{
    id: number,
    nome: string,
    email:string,
    cpf:string,
    endereco:string

    exibirInfo():void
    visualizarJogos(jogo:Jogo):void
}