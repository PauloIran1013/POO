export  class Jogo {
    static addJogo(jogo: Jogo) {
        throw new Error("Method not implemented.");
    }
    private id:number;
    private nome:string;
    private descricao:string;
    private genero:string;
    private plataforma:string;
    private preco:number;
    static jogosDisponiveis: Jogo[]=[]
    jogo: any;

    constructor(id: number, nome: string, genero: string, descricao: string, plataforma: string, preco: number) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.genero = genero;
        this.plataforma = plataforma;
        this.preco = preco;
        
    }

    
    public getId() : number {
        return this.id
    }
    
    public getNome() : string {
        return this.nome
    }
    
    public getDescricao() : string {
        return this.descricao
    }
    
    public setDescricao(novaDescricao:string) {
        this.descricao = novaDescricao
    }
    
    
    public getPlataforma() : string {
        return this.plataforma
    }
    
    public getPreco() : number {
        return this.preco
    }
    
    public setPreco(novoPreco:number) {
        if (novoPreco<=0) {
            console.log('Insira um valor válido');
            
        }
        else {
            this.preco = novoPreco;
        }
    }
    
    public exibirInfoJogo():void{
        console.log('Informações dos jogos');
        console.log(`Id:${this.id}`);
        console.log(`Nome:${this.nome}`);
        console.log(`Descrição:${this.descricao}`);
        console.log(`Plataforma:${this.plataforma}`);
        console.log(`Valor:${this.preco}`);
    }

    static listarJogos(jogo?: Jogo):void{
        console.log('Lista de jogos:')
        this.jogosDisponiveis.forEach((jogo)=>jogo.exibirInfoJogo())
    }
    
    public editarDescricao(novaDescricao:string):void{
        this.setDescricao(novaDescricao)    
    }

    public editarPreco(novoPreco:number):void{
        if (novoPreco <= 0) {
            console.log('Insira um valor válido');
    }else{
        console.log(`Novo Preço:${novoPreco}`);
        
    }
}

public aplicarDeconto(desconto:number):void{
    if (desconto <= 0) {
        console.log('Insira um valor válido');
        } else {
            const precoFinal = this.preco - (this.preco * desconto / 100);
            console.log(`Preço após o desconto:${precoFinal}`)
}
}

public  addJogo(jogo:Jogo){
    this.jogo.jogosDisponiveis.push(jogo);
}

}

// export class Jogo {
//     private id: number;
//     private nome: string;
//     private descricao: string;
//     private genero: string;
//     private plataforma: string;
//     private preco: number;
  
//     // Repositório estático para armazenar os jogos
//     static jogosDisponiveis: Jogo[] = [];
  
//     constructor(id: number, nome: string, genero: string, descricao: string, plataforma: string, preco: number) {
//       this.id = id;
//       this.nome = nome;
//       this.descricao = descricao;
//       this.genero = genero;
//       this.plataforma = plataforma;
//       this.preco = preco;
//     }
  
//     public getId(): number {
//       return this.id;
//     }
  
//     public getNome(): string {
//       return this.nome;
//     }
  
//     public getDescricao(): string {
//       return this.descricao;
//     }
  
//     public setDescricao(novaDescricao: string): void {
//       this.descricao = novaDescricao;
//     }
  
//     public getPlataforma(): string {
//       return this.plataforma;
//     }
  
//     public getPreco(): number {
//       return this.preco;
//     }
  
//     public setPreco(novoPreco: number): void {
//       if (novoPreco <= 0) {
//         console.log('Insira um valor válido');
//       } else {
//         this.preco = novoPreco;
//       }
//     }
  
//     public exibirInfoJogo(): void {
//       console.log('Informações do jogo');
//       console.log(`ID: ${this.id}`);
//       console.log(`Nome: ${this.nome}`);
//       console.log(`Descrição: ${this.descricao}`);
//       console.log(`Plataforma: ${this.plataforma}`);
//       console.log(`Preço: R$ ${this.preco.toFixed(2)}`);
//     }
  
//     // Método estático para listar os jogos
//     static listarJogos(): void {
//       console.log('Lista de jogos disponíveis:');
//       this.jogosDisponiveis.forEach((jogo) => jogo.exibirInfoJogo());
//     }
  
//     // Método estático para adicionar um jogo à lista de jogos
//     static adicionarJogo(jogo: Jogo): void {
//       this.jogosDisponiveis.push(jogo);
//       console.log(`Jogo "${jogo.getNome()}" adicionado à lista de jogos.`);
//     }
//   }
  